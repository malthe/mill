package foo
object Example{
  def hello(): String = "Hello World"
}